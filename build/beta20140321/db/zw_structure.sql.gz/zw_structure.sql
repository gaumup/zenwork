-- phpMyAdmin SQL Dump
-- version 3.2.4
-- http://www.phpmyadmin.net
--
-- Host: 10.30.7.73
-- Generation Time: Mar 21, 2014 at 02:10 PM
-- Server version: 5.0.77
-- PHP Version: 5.3.20

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `wo_onl`
--

-- --------------------------------------------------------

--
-- Table structure for table `acos`
--

DROP TABLE IF EXISTS `acos`;
CREATE TABLE IF NOT EXISTS `acos` (
  `id` int(10) NOT NULL auto_increment,
  `parent_id` int(10) default NULL,
  `foreign_key` int(10) default NULL,
  `alias` varchar(255) character set utf8 collate utf8_unicode_ci default NULL,
  `lft` int(10) default NULL,
  `rght` int(10) default NULL,
  `model` varchar(255) character set utf8 collate utf8_unicode_ci default NULL,
  `des_name` varchar(255) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=81 ;

-- --------------------------------------------------------

--
-- Table structure for table `aros`
--

DROP TABLE IF EXISTS `aros`;
CREATE TABLE IF NOT EXISTS `aros` (
  `id` int(10) NOT NULL auto_increment,
  `parent_id` int(10) default NULL,
  `foreign_key` int(10) default NULL,
  `alias` varchar(255) character set utf8 collate utf8_unicode_ci default NULL,
  `lft` int(10) default NULL,
  `rght` int(10) default NULL,
  `model` varchar(255) character set utf8 collate utf8_unicode_ci default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=214 ;

-- --------------------------------------------------------

--
-- Table structure for table `aros_acos`
--

DROP TABLE IF EXISTS `aros_acos`;
CREATE TABLE IF NOT EXISTS `aros_acos` (
  `id` int(10) NOT NULL auto_increment,
  `aro_id` int(10) NOT NULL,
  `aco_id` int(10) NOT NULL,
  `_create` varchar(2) character set utf8 collate utf8_unicode_ci NOT NULL default '0',
  `_read` varchar(2) character set utf8 collate utf8_unicode_ci NOT NULL default '0',
  `_update` varchar(2) character set utf8 collate utf8_unicode_ci NOT NULL default '0',
  `_delete` varchar(2) character set utf8 collate utf8_unicode_ci NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=653 ;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(10) NOT NULL auto_increment,
  `username` varchar(50) collate utf8_unicode_ci NOT NULL,
  `password` varchar(50) collate utf8_unicode_ci NOT NULL,
  `fullname` text collate utf8_unicode_ci NOT NULL,
  `gender` tinyint(4) NOT NULL,
  `birthday` int(11) default NULL,
  `email` varchar(255) collate utf8_unicode_ci NOT NULL,
  `mobile` varchar(15) collate utf8_unicode_ci default NULL,
  `ext` varchar(15) collate utf8_unicode_ci default NULL,
  `avatar` varchar(255) collate utf8_unicode_ci default NULL,
  `defaultTeamID` int(11) default NULL,
  `defaultPlanID` int(11) default NULL,
  `team_id` int(10) default NULL,
  `jobtitle_id` int(5) default NULL,
  `partner_id` int(11) default NULL,
  `wiki_user_level` tinyint(4) default '1',
  `is_blocked` tinyint(4) default '0',
  `key_reset_pwd` varchar(50) collate utf8_unicode_ci default NULL,
  `group_id` int(11) default '0',
  `description` text collate utf8_unicode_ci,
  `online` int(11) default '0',
  `createdOn` int(11) NOT NULL,
  `lastLogin` int(11) default NULL,
  PRIMARY KEY  (`id`),
  FULLTEXT KEY `FULLTEXT` (`username`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=173 ;

-- --------------------------------------------------------

--
-- Table structure for table `zw_attachments`
--

DROP TABLE IF EXISTS `zw_attachments`;
CREATE TABLE IF NOT EXISTS `zw_attachments` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(200) character set utf8 collate utf8_unicode_ci NOT NULL,
  `filename` varchar(200) character set utf8 collate utf8_unicode_ci NOT NULL,
  `size` varchar(10) NOT NULL,
  `ext` varchar(5) NOT NULL,
  `uploader` int(11) NOT NULL,
  `since` int(11) NOT NULL,
  `sid` int(11) NOT NULL,
  `cid` int(11) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=174 ;

-- --------------------------------------------------------

--
-- Table structure for table `zw_deliverables`
--

DROP TABLE IF EXISTS `zw_deliverables`;
CREATE TABLE IF NOT EXISTS `zw_deliverables` (
  `id` int(11) NOT NULL,
  `cateID` int(11) default NULL,
  `statusID` int(11) default NULL,
  `priorityID` int(11) NOT NULL default '2',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `zw_flows`
--

DROP TABLE IF EXISTS `zw_flows`;
CREATE TABLE IF NOT EXISTS `zw_flows` (
  `id` int(11) NOT NULL auto_increment,
  `status` int(11) NOT NULL,
  `alias` varchar(100) collate utf8_unicode_ci NOT NULL,
  `action` varchar(100) collate utf8_unicode_ci default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=6 ;

-- --------------------------------------------------------

--
-- Table structure for table `zw_helps`
--

DROP TABLE IF EXISTS `zw_helps`;
CREATE TABLE IF NOT EXISTS `zw_helps` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(255) collate utf8_unicode_ci NOT NULL,
  `controller` varchar(255) collate utf8_unicode_ci NOT NULL,
  `uid` text collate utf8_unicode_ci,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=23 ;

-- --------------------------------------------------------

--
-- Table structure for table `zw_lists`
--

DROP TABLE IF EXISTS `zw_lists`;
CREATE TABLE IF NOT EXISTS `zw_lists` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(255) collate utf8_unicode_ci NOT NULL,
  `creatorID` int(11) NOT NULL,
  `createdOn` int(10) NOT NULL,
  `description` text collate utf8_unicode_ci NOT NULL,
  `activeUID` int(11) default '0',
  `lastModified` int(10) default '0',
  `queue` text collate utf8_unicode_ci,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=76 ;

-- --------------------------------------------------------

--
-- Table structure for table `zw_scomments`
--

DROP TABLE IF EXISTS `zw_scomments`;
CREATE TABLE IF NOT EXISTS `zw_scomments` (
  `id` int(11) NOT NULL auto_increment,
  `comment` text collate utf8_unicode_ci NOT NULL,
  `by` int(11) NOT NULL,
  `when` int(11) NOT NULL,
  `sid` varchar(13) collate utf8_unicode_ci NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=525 ;

-- --------------------------------------------------------

--
-- Table structure for table `zw_streams`
--

DROP TABLE IF EXISTS `zw_streams`;
CREATE TABLE IF NOT EXISTS `zw_streams` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(250) collate utf8_unicode_ci default NULL,
  `completed` int(1) NOT NULL,
  `creatorID` int(11) NOT NULL,
  `description` text collate utf8_unicode_ci,
  `createdOn` int(10) NOT NULL,
  `streamExtendModel` varchar(255) collate utf8_unicode_ci default NULL,
  `tag` varchar(255) collate utf8_unicode_ci NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1790 ;

-- --------------------------------------------------------

--
-- Table structure for table `zw_streams_lists_map`
--

DROP TABLE IF EXISTS `zw_streams_lists_map`;
CREATE TABLE IF NOT EXISTS `zw_streams_lists_map` (
  `id` int(11) NOT NULL auto_increment,
  `sid` int(11) NOT NULL,
  `lid` int(11) NOT NULL,
  `parentID` int(11) default '0',
  `left` int(10) default NULL,
  `right` int(10) default NULL,
  `parentSlmID` int(10) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2540 ;

-- --------------------------------------------------------

--
-- Table structure for table `zw_stream_followers`
--

DROP TABLE IF EXISTS `zw_stream_followers`;
CREATE TABLE IF NOT EXISTS `zw_stream_followers` (
  `id` int(11) NOT NULL auto_increment,
  `sid` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=47 ;

-- --------------------------------------------------------

--
-- Table structure for table `zw_stream_logs`
--

DROP TABLE IF EXISTS `zw_stream_logs`;
CREATE TABLE IF NOT EXISTS `zw_stream_logs` (
  `id` int(11) NOT NULL auto_increment,
  `sid` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `action` text collate utf8_unicode_ci NOT NULL,
  `when` int(11) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=7297 ;

-- --------------------------------------------------------

--
-- Table structure for table `zw_stream_priorities`
--

DROP TABLE IF EXISTS `zw_stream_priorities`;
CREATE TABLE IF NOT EXISTS `zw_stream_priorities` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(20) collate utf8_unicode_ci NOT NULL,
  `description` text collate utf8_unicode_ci,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `zw_tags`
--

DROP TABLE IF EXISTS `zw_tags`;
CREATE TABLE IF NOT EXISTS `zw_tags` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(255) collate utf8_unicode_ci NOT NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=241 ;

-- --------------------------------------------------------

--
-- Table structure for table `zw_teams`
--

DROP TABLE IF EXISTS `zw_teams`;
CREATE TABLE IF NOT EXISTS `zw_teams` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(255) collate utf8_unicode_ci NOT NULL,
  `description` varchar(255) collate utf8_unicode_ci NOT NULL,
  `creatorID` int(11) NOT NULL,
  `createdOn` int(10) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=36 ;

-- --------------------------------------------------------

--
-- Table structure for table `zw_timelines`
--

DROP TABLE IF EXISTS `zw_timelines`;
CREATE TABLE IF NOT EXISTS `zw_timelines` (
  `id` int(11) NOT NULL auto_increment,
  `start` int(10) NOT NULL,
  `end` int(10) NOT NULL,
  `effort` float NOT NULL,
  `completed` int(1) NOT NULL default '0',
  `sid` int(11) NOT NULL,
  `createdOn` int(10) NOT NULL,
  `creatorID` int(11) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=1851 ;

-- --------------------------------------------------------

--
-- Table structure for table `zw_timeline_dependancies`
--

DROP TABLE IF EXISTS `zw_timeline_dependancies`;
CREATE TABLE IF NOT EXISTS `zw_timeline_dependancies` (
  `id` int(11) NOT NULL auto_increment,
  `tID1` int(11) NOT NULL,
  `tID2` int(11) NOT NULL,
  `rel` varchar(2) collate utf8_unicode_ci NOT NULL,
  `scopeID` int(11) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=80 ;

-- --------------------------------------------------------

--
-- Table structure for table `zw_users_lists`
--

DROP TABLE IF EXISTS `zw_users_lists`;
CREATE TABLE IF NOT EXISTS `zw_users_lists` (
  `id` int(11) NOT NULL auto_increment,
  `uid` int(11) NOT NULL,
  `lid` int(11) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=166 ;

-- --------------------------------------------------------

--
-- Table structure for table `zw_users_teams`
--

DROP TABLE IF EXISTS `zw_users_teams`;
CREATE TABLE IF NOT EXISTS `zw_users_teams` (
  `id` int(11) NOT NULL auto_increment,
  `tid` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=57 ;

-- --------------------------------------------------------

--
-- Table structure for table `zw_users_timelines`
--

DROP TABLE IF EXISTS `zw_users_timelines`;
CREATE TABLE IF NOT EXISTS `zw_users_timelines` (
  `id` int(11) NOT NULL auto_increment,
  `uid` int(11) NOT NULL,
  `tid` int(11) NOT NULL,
  `effort` float(11,4) NOT NULL default '0.0000',
  `completed` int(1) NOT NULL default '1',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=1442 ;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
