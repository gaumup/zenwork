-- phpMyAdmin SQL Dump
-- version 3.5.2.2
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Aug 16, 2013 at 07:28 AM
-- Server version: 5.5.27
-- PHP Version: 5.4.7

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `ims_dev`
--

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `fullname` text COLLATE utf8_unicode_ci NOT NULL,
  `gender` tinyint(4) NOT NULL,
  `birthday` int(11) DEFAULT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `mobile` varchar(15) COLLATE utf8_unicode_ci DEFAULT NULL,
  `avatar` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `defaultTeamID` int(11) DEFAULT NULL,
  `is_blocked` tinyint(4) DEFAULT '0',
  `key_reset_pwd` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `online` tinyint(1) DEFAULT NULL,
  `lastLogin` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  FULLTEXT KEY `FULLTEXT` (`username`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=110 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `fullname`, `gender`, `birthday`, `email`, `mobile`, `avatar`, `defaultTeamID`, `is_blocked`, `key_reset_pwd`, `online`, `lastLogin`) VALUES
(2, 'admin', '7043d2475163e4b16d3795327bb558b33a819b2a', 'Admin', 2, 505155600, 'admin@vng.com.vn', '0918374693', 'avatar_admin.jpg', NULL, 0, NULL, 0, 0),
(5, 'KhoaNT', '8914d500b90a21f6f42d6d4bc7da0da005964d94', 'Nguyễn Tiến Khoa', 2, 525459600, 'khoant@vng.com.vn', '0909261922', 'e4da3b7fbbce2345d7772b0674a318d5.png', 0, 0, 'b369ffcc843e6fa8084b6db35b6a30ba816df067', 1, 1376552912),
(6, 'QuanND', '7043d2475163e4b16d3795327bb558b33a819b2a', 'Nguyễn Đông Quân', 2, 345402000, 'quannd@vng.com.vn', '090984609501', '', NULL, 0, 'b9c8fb43ebd3594b1a3a65d9b5c90d0753d2130e', 0, 0),
(7, 'DatPTB', '7043d2475163e4b16d3795327bb558b33a819b2a', 'Phan Thị Bảo Đạt', 1, 465411600, 'datptb@vng.com.vn', '0909675789', 'avatar_DatPTB.jpg', NULL, 0, NULL, 0, 0),
(8, 'ThachHN', '7043d2475163e4b16d3795327bb558b33a819b2a', 'Hồ Ngọc Thạch', 2, 334861200, 'thachhn@vng.com.vn', '0938800812', 'avatar_ThachHN.jpg', NULL, 0, '', 0, 0),
(9, 'HaiTT2', '7043d2475163e4b16d3795327bb558b33a819b2a', 'Trần Thanh Hải', 2, 335725200, 'haitt2@vng.com.vn', '01234559496', '45c48cce2e2d7fbdea1afc51c7c6ad26.jpg', NULL, 0, NULL, 0, 0),
(10, 'TranNTB', '7043d2475163e4b16d3795327bb558b33a819b2a', 'Nguyễn Thị Bảo Trân', 1, 352400400, 'tranntb@vng.com.vn', '0909245458', 'avatar_TranNTB.jpg', NULL, 0, NULL, 0, 0),
(11, 'NgocDH', '7043d2475163e4b16d3795327bb558b33a819b2a', 'Đỗ Hồng Ngọc', 1, 355683600, 'ngocdh@vng.com.vn', '0937793435', 'avatar_NgocDH.jpg', NULL, 0, NULL, 0, 0),
(12, 'TrangBTT', '7043d2475163e4b16d3795327bb558b33a819b2a', 'Bùi Thị Thu Trang', 1, 414608400, 'trangbtt@vng.com.vn', '0989772606', 'avatar_TrangBTT.jpg', NULL, 0, NULL, 0, 0),
(13, 'HieuHT3', '7043d2475163e4b16d3795327bb558b33a819b2a', 'Huỳnh Trung Hiếu', 2, 595184400, 'hieuht3@vng.com.vn', '01203668686', 'avatar_HieuHT3.jpg', NULL, 0, NULL, 0, 0),
(14, 'PhuongTL', '7043d2475163e4b16d3795327bb558b33a819b2a', 'Trần Lệ Phương', 1, 379184400, 'phuongtl@vng.com.vn', '0913656985', 'avatar_PhuongTL.jpg', NULL, 0, NULL, 0, 0),
(15, 'VinhPQ', '7043d2475163e4b16d3795327bb558b33a819b2a', 'Phạm Quốc Vinh', 2, 363978000, 'vinhpq@vng.com.vn', '0907489765', 'avatar_VinhPQ.jpg', NULL, 0, NULL, 0, 0),
(16, 'TuanNDA', '7043d2475163e4b16d3795327bb558b33a819b2a', 'Nguyễn Đỗ Anh Tuấn', 2, 456253200, 'tuannda@vng.com.vn', '0908431014', 'avatar_TuanNDA.jpg', NULL, 0, NULL, 0, 0),
(51, 'BinhHV', '7043d2475163e4b16d3795327bb558b33a819b2a', 'Hoàng Văn Bình', 2, 0, 'binhhv@vng.com.vn', '091 292 5666', '', NULL, 0, NULL, 0, 0),
(18, 'TamDH', '7043d2475163e4b16d3795327bb558b33a819b2a', 'Đỗ Hiếu Tâm', 2, 535482000, 'tamdh@vng.com.vn', '0985848460', 'avatar_TamDH.jpg', NULL, 0, NULL, 0, 0),
(19, 'PhuongND2', '7043d2475163e4b16d3795327bb558b33a819b2a', 'Nguyễn Duy Phương', 2, 463770000, 'phuongnd2@vng.com.vn', '0904906100', 'avatar_PhuongND2.jpg', NULL, 0, NULL, 0, 0),
(20, 'VuLH', '7043d2475163e4b16d3795327bb558b33a819b2a', 'Lê Hoàng Vũ', 2, 437418000, 'vulh@vng.com.vn', '0985280033', 'avatar_VuLH.jpg', NULL, 0, NULL, 0, 0),
(21, 'MinhNTD', '7043d2475163e4b16d3795327bb558b33a819b2a', 'Nguyễn Trung Đức  Minh', 2, 476989200, 'minhntd@vng.com.vn', '0907079886', 'avatar_MinhNTD.jpg', NULL, 0, NULL, 0, 0),
(22, 'KhanhPH', '7043d2475163e4b16d3795327bb558b33a819b2a', 'Phạm Hoàng Khánh', 1, 501181200, 'khanhph@vng.com.vn', '0909628121', 'avatar_KhanhPH.jpg', NULL, 0, NULL, 0, 0),
(23, 'TungNM', '7043d2475163e4b16d3795327bb558b33a819b2a', 'Nguyễn Minh Tùng', 2, 385405200, 'tungnm@vng.com.vn', '0989298470', 'avatar_TungNM.jpg', NULL, 0, '751a4f1f976676b2267bb1503a96cca16d33a805', 0, 0),
(24, 'SonPT', '7043d2475163e4b16d3795327bb558b33a819b2a', 'Phạm Thanh Sơn', 2, 419101200, 'sonpt@vng.com.vn', '0937763834', '1ff1de774005f8da13f42943881c655f.jpg', NULL, 0, NULL, 0, 0),
(25, 'ThoaiNN', '7043d2475163e4b16d3795327bb558b33a819b2a', 'Nguyễn Ngọc  Thoại', 2, 378061200, 'thoainn@vng.com.vn', '0907314321', 'avatar_ThoaiNN.jpg', NULL, 1, NULL, 0, 0),
(26, 'OanhNVH', '7043d2475163e4b16d3795327bb558b33a819b2a', 'Nguyễn Vũ Hoàng Oanh', 1, 284058000, 'oanhnvh@vng.com.vn', '0906858184', 'avatar_OanhNVH.jpg', NULL, 0, NULL, 0, 0),
(27, 'VuNBPP', '7043d2475163e4b16d3795327bb558b33a819b2a', 'Ngô Bình Phương Phi Vũ', 2, 505155600, 'vunbpp@vng.com.vn', '0918374693', '02e74f10e0327ad868d138f2b4fdd6f0.jpg', NULL, 0, NULL, 1, 1376540128),
(28, 'TrungPT', '7043d2475163e4b16d3795327bb558b33a819b2a', 'Phan Trọng Trung', 2, 384282000, 'trungpt@vng.com.vn', '0917 492 703', '33e75ff09dd601bbe69f351039152189.jpg', NULL, 0, NULL, 0, 0),
(29, 'DungNP', '7043d2475163e4b16d3795327bb558b33a819b2a', 'Nguyễn Phương Dung', 1, 425408400, 'dungnp@vng.com.vn', '0908066693', 'avatar_DungNP.jpg', NULL, 0, NULL, 0, 0),
(30, 'KhoaVN', '7043d2475163e4b16d3795327bb558b33a819b2a', 'Vũ Nguyên Khoa', 2, 563562000, 'KhoaVN@vng.com.vn', '0985991901', NULL, NULL, 1, NULL, 0, 0),
(31, 'ThuanVK', '7043d2475163e4b16d3795327bb558b33a819b2a', 'Văn Khánh Thuận', 2, 449773200, 'thuanvk@vng.com.vn', '0938277345', 'avatar_ThuanVK.jpg', NULL, 0, NULL, 0, 0),
(32, 'LongNT', '7043d2475163e4b16d3795327bb558b33a819b2a', 'Nguyễn Thanh Long', 2, -599641200, 'longnt@vng.com.vn', '0909399382', 'avatar_LongNT.jpg', NULL, 1, NULL, 0, 0),
(33, 'TuTC', '7043d2475163e4b16d3795327bb558b33a819b2a', 'Trần Cẩm Tú', 2, 442170000, 'tutc@vng.com.vn', '0989300290', 'avatar_TuTC.jpg', NULL, 0, NULL, 0, 0),
(34, 'HieuTT2', '7043d2475163e4b16d3795327bb558b33a819b2a', 'Trần Trung Hiếu', 2, 387997200, 'hieutt2@vng.com.vn', '0936417291', 'avatar_HieuTT2.jpg', NULL, 1, NULL, 0, 0),
(36, 'HaiMT', '7043d2475163e4b16d3795327bb558b33a819b2a', 'Mai Thanh Hải', 2, -25200, 'haimt@vng.com.vn', '', '', NULL, 0, NULL, 0, 0),
(37, 'NhanLT2', '7043d2475163e4b16d3795327bb558b33a819b2a', 'Lê Trọng Nhân', 2, -25200, 'nhanlt2@vng.com.vn', '', '', NULL, 0, NULL, 0, 0),
(38, 'TranTTT', '7043d2475163e4b16d3795327bb558b33a819b2a', 'Trần Thị Thái Trân', 1, 524682000, 'tranttt@vng.com.vn', '0984755060', 'avatar_TranTTT.jpg', NULL, 0, NULL, 0, 0),
(39, 'HanhDM', '7043d2475163e4b16d3795327bb558b33a819b2a', 'Đỗ Mỹ Hạnh', 1, 630435600, 'hanhdm@vng.com.vn', '0905615099', NULL, NULL, 0, '175f5fe40f29b9e929b5a99afbdc15ece1645554', 0, 0),
(41, 'NhatLT', '7043d2475163e4b16d3795327bb558b33a819b2a', 'Lê Thanh Nhật', 2, 628707600, 'nhatlt@vng.com.vn', '0909470412', 'avatar_NhatLT.jpg', NULL, 0, NULL, 0, 0),
(42, 'CTVWDesign', '7043d2475163e4b16d3795327bb558b33a819b2a', 'Cộng tác viên Web Design', 2, 661798800, 'ctvwdesign@vng.com.vn', '0915136541', 'avatar_CTVWebDesign.gif', NULL, 0, NULL, 0, 0),
(44, 'CTVWDev', '7043d2475163e4b16d3795327bb558b33a819b2a', 'Công tác viên Web Dev', 1, 504896400, 'ctvwdev@vng.com.vn', '0937793435', 'avatar_CTVWDev.jpg', NULL, 0, NULL, 0, 0),
(45, 'DatPPT', '7043d2475163e4b16d3795327bb558b33a819b2a', 'Pham Phan Tien Dat', 2, -25200, 'datppt@vng.com.vn', '', '', NULL, 0, NULL, 0, 0),
(46, 'KietPT', '7043d2475163e4b16d3795327bb558b33a819b2a', 'Phan Tan Kiet', 2, -25200, 'kietpt@vng.com.vn', '', '', NULL, 0, NULL, 0, 0),
(47, 'AnhDQB', '7043d2475163e4b16d3795327bb558b33a819b2a', 'Dang Quoc Bao Anh', 2, -25200, 'anhdqb@vng.com.vn', '', '', NULL, 0, NULL, 0, 0),
(50, 'TrangNTT2', '7043d2475163e4b16d3795327bb558b33a819b2a', 'Nguyễn Thị Thúy Trang', 1, 0, 'trangntt2@vng.com.vn', '090 810 3076', '', NULL, 0, NULL, 0, 0),
(48, 'AnhNLH', '7043d2475163e4b16d3795327bb558b33a819b2a', 'anhnlh@vng.com.vn', 1, -25200, 'anhnlh@vng.com.vn', '', '', NULL, 0, NULL, 0, 0),
(52, 'partner', '7043d2475163e4b16d3795327bb558b33a819b2a', 'PGs/Partners', 1, 1094662800, 'partner@vng.com.vn', '', NULL, NULL, 0, NULL, 0, 0),
(53, 'PhuongHT2', '7043d2475163e4b16d3795327bb558b33a819b2a', 'PhuongHT2', 1, 651776400, 'phuonght2@vng.com.vn', '0906589850', 'avatar_PhuongHT2.jpg', NULL, 0, NULL, 0, 0),
(55, 'ThuanLQ', '7043d2475163e4b16d3795327bb558b33a819b2a', 'Lê Quang Thuận', 2, 0, 'thuanlq@vng.com.vn', '0909 711 333', '', NULL, 0, NULL, 0, 0),
(56, 'OanhTTK2', '7043d2475163e4b16d3795327bb558b33a819b2a', 'Trần Thị Kim Oanh', 1, -25200, 'oanhttk2@vng.com.vn', '', '', NULL, 0, NULL, 0, 0),
(17, 'NhutNQ', '7043d2475163e4b16d3795327bb558b33a819b2a', 'Nguyễn Quang Nhựt', 2, 524077200, 'nhutnq@vng.com.vn', '', 'avatar_NhutNQ.jpg', NULL, 1, NULL, 0, 0),
(60, 'ViTT', '7043d2475163e4b16d3795327bb558b33a819b2a', 'Trương Thành Vĩ', 1, 488653200, 'vitt@vng.com.vn', '', '072b030ba126b2f4b2374f342be9ed44.jpg', NULL, 0, NULL, 0, 0),
(61, 'NgocTTM', '7043d2475163e4b16d3795327bb558b33a819b2a', 'Trần Thị Mỹ Ngọc', 1, 546886800, 'ngocttm@vng.com.vn', '', NULL, NULL, 0, NULL, 0, 0),
(62, 'QuangNC', '7043d2475163e4b16d3795327bb558b33a819b2a', 'Nguyễn Chánh Quang', 2, 0, 'quangnc@vng.com.vn', '', '', NULL, 0, NULL, 0, 0),
(63, 'ThuyVB', '7043d2475163e4b16d3795327bb558b33a819b2a', 'ThuyVB', 1, 0, 'thuyvb@vng.com.vn', '', '', NULL, 0, NULL, 0, 0),
(64, 'TuTN', '7043d2475163e4b16d3795327bb558b33a819b2a', 'Trần Ngọc Tú', 1, 0, 'tutn@vng.com.vn', '0983080145', '', NULL, 0, NULL, 0, 0),
(65, 'YVN', '7043d2475163e4b16d3795327bb558b33a819b2a', 'Võ Như Ý', 2, 0, 'yvn@vng.com.vn', '', '', NULL, 0, NULL, 0, 0),
(66, 'HanhNTM', '7043d2475163e4b16d3795327bb558b33a819b2a', 'Nguyễn Thị Mỹ Hạnh', 1, 0, 'hanhntm@vng.com.vn', '0909 075 147', '', NULL, 0, NULL, 0, 0),
(68, 'TuanNLA', '7043d2475163e4b16d3795327bb558b33a819b2a', 'Ngô Lê Anh Tuấn', 1, 0, 'tuannla@vng.com.vn', '', NULL, NULL, 0, NULL, 0, 0),
(74, 'VanHAH', '7043d2475163e4b16d3795327bb558b33a819b2a', 'Hồ Ánh Hồng Vân', 1, 0, 'vanhah@vng.com.vn', '', NULL, NULL, 0, NULL, 0, 0),
(79, 'LeVTM', '7043d2475163e4b16d3795327bb558b33a819b2a', 'Võ Thị Mỹ Lệ', 1, 567968400, 'levtm@vng.com.vn', '0976083081', NULL, NULL, 0, NULL, 0, 0),
(67, 'HaNM2', '7043d2475163e4b16d3795327bb558b33a819b2a', 'Nguyễn Mạnh Hà', 2, 474570000, 'hanm2@vng.com.vn', '01227686962', NULL, NULL, 0, NULL, 0, 0),
(72, 'DatKG', '7043d2475163e4b16d3795327bb558b33a819b2a', 'Khưu Gia Đạt', 2, 0, 'datkg@vng.com.vn', '', NULL, NULL, 0, NULL, 0, 0),
(80, 'TramTDD', '7043d2475163e4b16d3795327bb558b33a819b2a', 'Trương Đình Đăng Trâm', 1, 0, 'tramtdd@vng.com.vn', '0983474170', NULL, NULL, 0, NULL, 0, 0),
(76, 'PhienPTH', '7043d2475163e4b16d3795327bb558b33a819b2a', 'Phạm Thị Hồng Phiên', 1, 623091600, 'phienpth@vng.com.vn', '0169 8069 204', 'fbd7939d674997cdb4692d34de8633c4.jpg', NULL, 0, NULL, 0, 0),
(77, 'ThaoTP2', '7043d2475163e4b16d3795327bb558b33a819b2a', 'Trần Phan Thảo', 1, 610304400, 'thaotp2@vng.com.vn', '', NULL, NULL, 0, NULL, 0, 0),
(78, 'VinhVT3', '7043d2475163e4b16d3795327bb558b33a819b2a', 'Vũ Thành Vĩnh', 2, 654973200, 'VinhVT3@vng.com.vn', '', NULL, NULL, 1, NULL, 0, 0),
(81, 'TuanPHM', '7043d2475163e4b16d3795327bb558b33a819b2a', 'Phạm Hoàng Minh Tuấn', 2, 636570000, 'tuanphm@vng.com.vn', '', NULL, NULL, 0, NULL, 0, 0),
(82, 'MayTC', '7043d2475163e4b16d3795327bb558b33a819b2a', 'Trần Chân Mây', 1, 0, 'maytc@vng.com.vn', '01212644925', NULL, NULL, 0, NULL, 0, 0),
(83, 'BinhLV', '7043d2475163e4b16d3795327bb558b33a819b2a', 'Lê Văn Bình', 2, 560365200, 'binhlv@vng.com.vn', '01698325327', 'fe9fc289c3ff0af142b6d3bead98a923.jpg', NULL, 0, NULL, 0, 0),
(84, 'TyNB', '7043d2475163e4b16d3795327bb558b33a819b2a', 'Nguyễn Bá Tỵ', 2, 620672400, 'tynb@vng.com.vn', '0974483383', '68d30a9594728bc39aa24be94b319d21.jpg', NULL, 0, NULL, 0, 0),
(85, 'ThangNV', '7043d2475163e4b16d3795327bb558b33a819b2a', 'Nguyễn Văn Thẳng', 2, 508525200, 'thangnv@vng.com.vn', '0945147888', NULL, NULL, 0, 'fb4816178232a8314bb61dbbe8e5269312525128', 0, 0),
(86, 'VinhVT', '7043d2475163e4b16d3795327bb558b33a819b2a', 'Vũ Thị Vinh', 1, 436899600, 'vinhvt@vng.com.vn', '0987005221', NULL, NULL, 0, '64b846710b0ac9fe8b018e9962a2d2da309d23e0', 0, 0),
(87, 'VyVK', '7043d2475163e4b16d3795327bb558b33a819b2a', 'Vương Khả Vy', 1, 0, 'vyvk@vng.com.vn', '091 888 0128', NULL, NULL, 0, NULL, 0, 0),
(88, 'HiepNQ', '7043d2475163e4b16d3795327bb558b33a819b2a', 'Nguyễn Quý Hiệp', 2, 465066000, 'hiep@vng.com.vn', '091 847 2079', '2a38a4a9316c49e5a833517c45d31070.jpg', NULL, 0, NULL, 0, 0),
(89, 'ThuPTM', '7043d2475163e4b16d3795327bb558b33a819b2a', 'Phạm Thị Minh Thư', 1, 0, 'thuptm@vng.com.vn', '0909 669 871', NULL, NULL, 0, NULL, 0, 0),
(90, 'LuatDT', '7043d2475163e4b16d3795327bb558b33a819b2a', 'Đoàn Tường Luật', 2, 0, 'luatdt@vng.com.vn', '0908358411', NULL, NULL, 0, NULL, 0, 0),
(92, 'HienHTQ', '7043d2475163e4b16d3795327bb558b33a819b2a', 'Huỳnh Trần Quốc Hiển', 2, 483728400, 'hienhtq@vng.com.vn', '01695 183 997', NULL, NULL, 0, NULL, 0, 0),
(93, 'LeDY', '7043d2475163e4b16d3795327bb558b33a819b2a', 'Diệp Yến Lệ', 1, 562438800, 'ledy@vng.com.vn', '0903 823 358', NULL, NULL, 0, '2f399825f4c0d145a77ccf223311b0b1d76b3593', 0, 0),
(94, 'TrinhBVK', '7043d2475163e4b16d3795327bb558b33a819b2a', 'Bùi Vũ Kiều Trinh', 1, 0, 'trinhbvk@vng.com.vn', '0977 850 304', NULL, NULL, 0, NULL, 0, 0),
(95, 'KhueTTA', '7043d2475163e4b16d3795327bb558b33a819b2a', 'Trần Thị Anh Khuê', 1, 610822800, 'khuetta@vng.com.vn', '0975 639 273', NULL, NULL, 0, 'eb54fc5d810d97fb63fd1003b9b7928f68a50ac1', 0, 0),
(96, 'NgocGB', '7043d2475163e4b16d3795327bb558b33a819b2a', 'Giang Bảo Ngọc', 1, 443552400, 'ngocgb@vng.com.vn', '0938073607', NULL, NULL, 0, NULL, 0, 0),
(97, 'ChauNBL', '7043d2475163e4b16d3795327bb558b33a819b2a', 'Nguyễn Bảo Linh Châu', 1, 501094800, 'chaunbl@vng.com.vn', '', NULL, NULL, 0, NULL, 0, 0),
(98, 'TuanNA4', '7043d2475163e4b16d3795327bb558b33a819b2a', 'Nguyễn Anh Tuấn', 2, NULL, 'TuanNA4@vng.com.vn', '', NULL, NULL, 0, NULL, 0, 0),
(99, 'ThanhVB', '7043d2475163e4b16d3795327bb558b33a819b2a', 'Văn Bá Thanh', 2, NULL, 'ThanhVB@vng.com.vn', '', NULL, NULL, 0, NULL, 0, 0),
(100, 'TuyenND2', '7043d2475163e4b16d3795327bb558b33a819b2a', 'Nguyễn Duy Tuyên', 2, NULL, 'TuyenND2@vng.com.vn', '', NULL, NULL, 0, NULL, 0, 0),
(101, 'PhuongHNA', '7043d2475163e4b16d3795327bb558b33a819b2a', 'Huỳnh Nguyễn Ánh Phương', 1, 0, 'phuonghna@vng.com.vn', '', NULL, NULL, 0, NULL, 0, 0),
(102, 'TuPT', '7043d2475163e4b16d3795327bb558b33a819b2a', 'Phạm Thanh Tú', 1, 0, 'tupt@vng.com.vn', '', NULL, NULL, 0, NULL, 0, 0),
(103, 'LanTH', '7043d2475163e4b16d3795327bb558b33a819b2a', 'Thái Hồng Lân', 2, 381171600, 'lanth@vng.com.vn', '0902526682', '6974ce5ac660610b44d9b9fed0ff9548.jpg', NULL, 0, NULL, 0, 0),
(104, 'DinhLTK', '7043d2475163e4b16d3795327bb558b33a819b2a', 'Lê Thị Kim Đính', 1, NULL, 'dinhltk@vng.com.vn', '', NULL, NULL, 0, 'f05056e56b8d7fe93ddc368cb49d20b4f9f991c9', 0, 0),
(105, 'ThaoTX', '7043d2475163e4b16d3795327bb558b33a819b2a', 'Trần Xuân Thảo', 1, 0, 'thaotx@cng.com.vn', '', NULL, NULL, 0, NULL, 0, 0),
(106, 'TramNB', '7043d2475163e4b16d3795327bb558b33a819b2a', 'Nguyễn Bích Trâm', 1, 0, 'tramnb@vng.com.vn', '', NULL, NULL, 0, NULL, 0, 0),
(107, 'ThanhDD', '7043d2475163e4b16d3795327bb558b33a819b2a', 'Đào Duy Thanh', 2, 631904400, 'thanhdd@vng.com.vn', '01204461055', NULL, NULL, 0, NULL, 0, 0),
(108, 'NhanLT5', '7043d2475163e4b16d3795327bb558b33a819b2a', 'Lê Trọng Nhân', 2, NULL, 'nhanlt5@vng.com.vn', '', 'a3c65c2974270fd093ee8a9bf8ae7d0b.jpg', NULL, 0, NULL, 0, 0),
(109, 'qc', '7043d2475163e4b16d3795327bb558b33a819b2a', 'QC', 2, 1264957200, 'qc@vng.com.vn', '', NULL, NULL, 0, NULL, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `zw_attachments`
--

DROP TABLE IF EXISTS `zw_attachments`;
CREATE TABLE IF NOT EXISTS `zw_attachments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `filename` varchar(200) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `size` varchar(10) NOT NULL,
  `ext` varchar(5) NOT NULL,
  `uploader` int(11) NOT NULL,
  `since` int(11) NOT NULL,
  `sid` int(11) NOT NULL,
  `cid` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=148 ;

--
-- Dumping data for table `zw_attachments`
--

INSERT INTO `zw_attachments` (`id`, `name`, `filename`, `size`, `ext`, `uploader`, `since`, `sid`, `cid`) VALUES
(147, 'agileprojectmanagement.pdf', 'e24f2d8bc131d660917fb90c4e36b369.pdf', '3018992', 'pdf', 27, 1376238179, 1169, 193);

-- --------------------------------------------------------

--
-- Table structure for table `zw_deliverables`
--

DROP TABLE IF EXISTS `zw_deliverables`;
CREATE TABLE IF NOT EXISTS `zw_deliverables` (
  `id` int(11) NOT NULL,
  `cateID` int(11) DEFAULT NULL,
  `statusID` int(11) DEFAULT NULL,
  `priorityID` int(11) NOT NULL DEFAULT '2',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `zw_flows`
--

DROP TABLE IF EXISTS `zw_flows`;
CREATE TABLE IF NOT EXISTS `zw_flows` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `status` int(11) NOT NULL,
  `alias` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `action` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=6 ;

--
-- Dumping data for table `zw_flows`
--

INSERT INTO `zw_flows` (`id`, `status`, `alias`, `action`) VALUES
(1, 0, 'New', 'Assign'),
(2, 1, 'Assigned', 'Accept'),
(3, 2, 'On working', 'Finish'),
(4, 3, 'Verifying', 'Close'),
(5, 4, 'Closed', '');

-- --------------------------------------------------------

--
-- Table structure for table `zw_helps`
--

DROP TABLE IF EXISTS `zw_helps`;
CREATE TABLE IF NOT EXISTS `zw_helps` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `controller` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `uid` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=23 ;

--
-- Dumping data for table `zw_helps`
--

INSERT INTO `zw_helps` (`id`, `name`, `controller`, `uid`) VALUES
(1, 'addNewStreamTextButton', 'dashboard', '5'),
(2, 'addNewStreamQuickButton', 'dashboard', '5,27'),
(3, 'userMonthlyWorkloadChartExplanation', 'dashboard', '5,27'),
(4, 'editStreamSubjectFirstTime', 'dashboard', '5'),
(5, 'streamListExplanation', 'dashboard', '5'),
(6, 'moveStreamToListFirstTime', 'dashboard', '5'),
(7, 'streamTaggingFirstTime', 'dashboard', '5'),
(8, 'timelineDurationAndAssigneeFirstTime', 'dashboard', '5'),
(9, 'todayListExplanation', 'dashboard', '5,27'),
(10, 'timelineStartWorkingFirstTime', 'dashboard', '5,27'),
(11, 'timelineCompletionFirstTime', 'dashboard', ''),
(12, 'streamListSelection', 'planner', '5,27'),
(13, 'createFirstStreamList', 'planner', '5,27'),
(14, 'addFirstStreamIntoList', 'planner', '5,27'),
(15, 'viewStreamDetailsFirstTime', 'planner', '5'),
(16, 'streamContextFirstTime', 'planner', '5'),
(17, 'streamReorderFirstTime', 'planner', '5'),
(19, 'firstCreatedTimeline', 'planner', '5'),
(20, 'alphaVersionFirstLogin', 'app', '5,27'),
(21, 'teamSelectionFirstTime', 'dashboard', '5'),
(22, 'createFirstTeam', 'dashboard', '5');

-- --------------------------------------------------------

--
-- Table structure for table `zw_lists`
--

DROP TABLE IF EXISTS `zw_lists`;
CREATE TABLE IF NOT EXISTS `zw_lists` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `creatorID` int(11) NOT NULL,
  `createdOn` int(10) NOT NULL,
  `description` text COLLATE utf8_unicode_ci NOT NULL,
  `activeUID` int(11) DEFAULT '0',
  `lastModified` int(10) DEFAULT '0',
  `queue` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=64 ;

--
-- Dumping data for table `zw_lists`
--

INSERT INTO `zw_lists` (`id`, `name`, `creatorID`, `createdOn`, `description`, `activeUID`, `lastModified`, `queue`) VALUES
(1, '[default]', 0, 0, '[default]', 0, 0, '0'),
(59, 'My Aug 2013', 5, 1376539658, 'My personal plan in Aug 2013', 0, 0, NULL),
(61, 'VMAS Phase 2', 5, 1376237849, 'VMAS plan cho giai đoạn 2', 0, 0, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `zw_scomments`
--

DROP TABLE IF EXISTS `zw_scomments`;
CREATE TABLE IF NOT EXISTS `zw_scomments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `comment` text COLLATE utf8_unicode_ci NOT NULL,
  `by` int(11) NOT NULL,
  `when` int(11) NOT NULL,
  `sid` varchar(13) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=206 ;

--
-- Dumping data for table `zw_scomments`
--

INSERT INTO `zw_scomments` (`id`, `comment`, `by`, `when`, `sid`) VALUES
(204, '09090', 27, 1376383515, '1190'),
(205, '0000', 27, 1376383556, '1190'),
(198, 'df', 5, 1376383075, '1190'),
(195, 'dfgfdgfd', 5, 1376382978, '1190'),
(196, 'ewfdsfds', 5, 1376383008, '1190'),
(197, 'dgdfgd', 5, 1376383026, '1190'),
(194, 'fdddt', 5, 1376382763, '1190'),
(192, 'Sau khi thiết kế xong, KhoaNT sẽ review nhé', 27, 1376237924, '1167'),
(193, 'Tham khảo yêu cầu từ VMAS team', 27, 1376238179, '1169'),
(199, 'sdf', 5, 1376383097, '1190'),
(200, 'sdfds', 5, 1376383177, '1190'),
(201, 'uuui', 27, 1376383418, '1190'),
(202, 'oiuhppm', 27, 1376383436, '1190'),
(203, 'oooo', 27, 1376383455, '1190');

-- --------------------------------------------------------

--
-- Table structure for table `zw_streams`
--

DROP TABLE IF EXISTS `zw_streams`;
CREATE TABLE IF NOT EXISTS `zw_streams` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `completed` int(1) NOT NULL,
  `creatorID` int(11) NOT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `createdOn` int(10) NOT NULL,
  `streamExtendModel` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tag` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1196 ;

--
-- Dumping data for table `zw_streams`
--

INSERT INTO `zw_streams` (`id`, `name`, `completed`, `creatorID`, `description`, `createdOn`, `streamExtendModel`, `tag`) VALUES
(1179, 'Apply designed UI', 0, 27, '', 1376240570, 'Task', ''),
(1178, 'Collect requirement from VMAS', 0, 27, '', 1376240569, 'Task', ''),
(1177, 'HTML component', 0, 27, '', 1376240515, 'Task', ''),
(1176, 'Coding HTML', 0, 27, '', 1376240515, 'Task', ''),
(1175, 'Design UI', 0, 27, '', 1376240509, 'Task', ''),
(1174, 'Implementing UI', 0, 27, '', 1376240509, 'Task', ''),
(1173, 'Set-up environment', 0, 27, '', 1376240509, 'Task', ''),
(1172, 'Start-up meeting', 0, 27, '', 1376240508, 'Task', ''),
(1171, 'Review all documents', 0, 27, '', 1376240508, 'Task', ''),
(1170, 'Product Comparison concept planning', 0, 27, '', 1376240507, 'Task', ''),
(1169, 'Coding Product Comparison module for VMAS', 0, 27, 'Coding moduel Product Comparison theo yêu cầu từ VMAS team', 1376238077, 'Task', 'vmas,phase 2'),
(1155, 'New task 1', 0, 5, '', 1376123533, 'Task', ''),
(1183, '2', 1, 5, '', 1376278657, 'Task', ''),
(1184, '3', 0, 5, '', 1376279340, 'Task', ''),
(1167, 'Preparing database for VMAS Phase 2', 0, 27, 'Thiết kế database mới cho VMAS giai đoạn 2', 1376237801, 'Task', 'vmas,database'),
(1190, 'Test 2344', 0, 5, 'sfffsdfdsfdssfdsdsfsdfdsfdsfdssfddsffdsfdsfdsfs sdfdsfdsfssdgffdsgfd', 1376360790, 'Task', ''),
(1168, 'Maintenance IMS', 0, 27, 'Update các lỗi trong IMS P1 mới được report', 1376237934, 'Task', 'ims,bug');

-- --------------------------------------------------------

--
-- Table structure for table `zw_streams_lists_map`
--

DROP TABLE IF EXISTS `zw_streams_lists_map`;
CREATE TABLE IF NOT EXISTS `zw_streams_lists_map` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sid` int(11) NOT NULL,
  `lid` int(11) NOT NULL,
  `parentID` int(11) DEFAULT '0',
  `left` int(10) DEFAULT NULL,
  `right` int(10) DEFAULT NULL,
  `parentSlmID` int(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=520 ;

--
-- Dumping data for table `zw_streams_lists_map`
--

INSERT INTO `zw_streams_lists_map` (`id`, `sid`, `lid`, `parentID`, `left`, `right`, `parentSlmID`) VALUES
(490, 1167, 61, 0, 17, 18, NULL),
(493, 1169, 61, 0, 21, 22, NULL),
(507, 1183, 59, 0, 3, 4, NULL),
(514, 1190, 1, 0, 5, 6, NULL),
(476, 1155, 59, 0, 1, 2, NULL),
(508, 1184, 59, 0, 5, 6, NULL),
(491, 1168, 1, 0, 3, 4, NULL),
(495, 1171, 61, 1178, 26, 27, 502),
(496, 1172, 61, 1178, 28, 29, 502),
(497, 1173, 61, 1178, 30, 31, 502),
(494, 1170, 61, 1178, 24, 25, 502),
(498, 1174, 61, 0, 33, 42, NULL),
(499, 1175, 61, 1174, 34, 35, 498),
(500, 1176, 61, 1174, 36, 41, 498),
(501, 1177, 61, 1176, 37, 38, 500),
(502, 1178, 61, 0, 23, 32, NULL),
(503, 1179, 61, 1176, 39, 40, 500);

-- --------------------------------------------------------

--
-- Table structure for table `zw_stream_followers`
--

DROP TABLE IF EXISTS `zw_stream_followers`;
CREATE TABLE IF NOT EXISTS `zw_stream_followers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sid` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=28 ;

--
-- Dumping data for table `zw_stream_followers`
--

INSERT INTO `zw_stream_followers` (`id`, `sid`, `uid`) VALUES
(24, 1183, 5),
(15, 1190, 86),
(16, 1190, 84),
(27, 1190, 5);

-- --------------------------------------------------------

--
-- Table structure for table `zw_stream_logs`
--

DROP TABLE IF EXISTS `zw_stream_logs`;
CREATE TABLE IF NOT EXISTS `zw_stream_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sid` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `action` text COLLATE utf8_unicode_ci NOT NULL,
  `when` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1306 ;

--
-- Dumping data for table `zw_stream_logs`
--

INSERT INTO `zw_stream_logs` (`id`, `sid`, `uid`, `action`, `when`) VALUES
(1295, 1190, 27, 'post a comment "0000"', 1376383556),
(1293, 1190, 27, 'post a comment "oooo"', 1376383455),
(1294, 1190, 27, 'post a comment "09090"', 1376383515),
(1283, 1190, 5, 'post a comment "fdddt"', 1376382763),
(1284, 1190, 5, 'post a comment "dfgfdgfd"', 1376382978),
(1285, 1190, 5, 'post a comment "ewfdsfds"', 1376383008),
(1286, 1190, 5, 'post a comment "dgdfgd"', 1376383026),
(1287, 1190, 5, 'post a comment "df"', 1376383075),
(1288, 1190, 5, 'post a comment "sdf"', 1376383097),
(1289, 1190, 5, 'post a comment "sdfds"', 1376383177),
(1290, 1190, 5, 'assign this to VuNBPP', 1376383377),
(1291, 1190, 27, 'post a comment "uuui"', 1376383418),
(1292, 1190, 27, 'post a comment "oiuhppm"', 1376383436),
(1253, 1184, 5, 'add a new timeline', 1376279341),
(1254, 1184, 5, 'add a new timeline', 1376279359),
(1255, 1184, 5, 'assign this to KhoaNT', 1376279365),
(1256, 1184, 5, 'assign this to KhoaNT', 1376279369),
(1257, 1155, 5, 'assign this to KhoaNT', 1376279383),
(1305, 1184, 5, 'assign this to TungNM', 1376622532),
(1304, 1184, 5, 'update QuanND effort to 8 wdays', 1376560027),
(1303, 1184, 5, 'assign this to QuanND', 1376560024),
(1302, 1169, 5, 'completed his assigned timeline(from 14-Aug-2013 to 15-Aug-2013)', 1376551484),
(1301, 1169, 5, 'update KhoaNT effort to 4 wdays', 1376551459),
(1165, 1155, 5, 'assign this to KhoaNT', 1376124718),
(1164, 1155, 5, 'add a new timeline', 1376124625),
(1161, 1155, 5, 'create this', 1376123533),
(1162, 1155, 5, 'add a new timeline', 1376123533),
(1163, 1155, 5, 'add a new timeline', 1376124279),
(1252, 1184, 5, 'create this', 1376279340),
(1251, 1183, 5, 'completed his assigned timeline(from 29-Aug-2013 to 13-Sep-2013)', 1376278715),
(1250, 1183, 5, 'update KhoaNT effort to 5 wdays', 1376278708),
(1249, 1183, 5, 'assign this to KhoaNT', 1376278671),
(1248, 1183, 5, 'add a new timeline', 1376278657),
(1245, 1155, 5, 'update KhoaNT effort to 12 wdays', 1376278515),
(1246, 1155, 5, 'update KhoaNT effort to 4 wdays', 1376278520),
(1247, 1183, 5, 'create this', 1376278657),
(1226, 1155, 5, 'assign this to KhoaNT', 1376275795),
(1227, 1155, 5, 'update KhoaNT effort to 6 wdays', 1376275801),
(1244, 1155, 5, 'update KhoaNT effort to 10 wdays', 1376278502),
(1243, 1155, 5, 'update KhoaNT effort to 5 wdays', 1376278490),
(1241, 1155, 5, 'completed his assigned timeline(from 12-Aug-2013 to 23-Aug-2013)', 1376277994),
(1239, 1155, 5, 'completed his assigned timeline(from 12-Aug-2013 to 16-Aug-2013)', 1376277917),
(1238, 1155, 5, 'update KhoaNT effort to 4 wdays', 1376277911),
(1191, 1167, 27, 'move this task from list "[default]" to list "VMAS Phase 2"', 1376237875),
(1190, 1167, 27, 'create this', 1376237801),
(1240, 1155, 5, 'update KhoaNT effort to 2 wdays', 1376277992),
(1242, 1155, 5, 'update KhoaNT effort to 5 wdays', 1376278489),
(1192, 1167, 27, 'assign this to VuNBPP', 1376237908),
(1193, 1167, 27, 'update VuNBPP effort to 3 wdays', 1376237910),
(1194, 1167, 27, 'post a comment "Sau khi thiết kế xong, KhoaNT sẽ review nhé"', 1376237924),
(1195, 1168, 27, 'create this', 1376237934),
(1196, 1168, 27, 'assign this to VuNBPP', 1376238010),
(1197, 1168, 27, 'update VuNBPP effort to 2 wdays', 1376238012),
(1198, 1169, 27, 'create this', 1376238077),
(1199, 1169, 27, 'move this task from list "[default]" to list "VMAS Phase 2"', 1376238102),
(1200, 1169, 27, 'assign this to VuNBPP', 1376238184),
(1201, 1169, 27, 'update VuNBPP effort to 5 wdays', 1376238187),
(1202, 1170, 27, 'create this', 1376240507),
(1203, 1170, 27, 'add a new timeline', 1376240507),
(1204, 1171, 27, 'create this', 1376240508),
(1205, 1171, 27, 'add a new timeline', 1376240508),
(1206, 1172, 27, 'create this', 1376240508),
(1207, 1172, 27, 'add a new timeline', 1376240508),
(1208, 1173, 27, 'create this', 1376240509),
(1209, 1173, 27, 'add a new timeline', 1376240509),
(1210, 1174, 27, 'create this', 1376240509),
(1211, 1174, 27, 'add a new timeline', 1376240509),
(1212, 1175, 27, 'create this', 1376240509),
(1213, 1175, 27, 'add a new timeline', 1376240510),
(1214, 1176, 27, 'create this', 1376240515),
(1215, 1176, 27, 'add a new timeline', 1376240515),
(1216, 1177, 27, 'create this', 1376240515),
(1217, 1177, 27, 'add a new timeline', 1376240515),
(1218, 1178, 27, 'create this', 1376240569),
(1219, 1178, 27, 'add a new timeline', 1376240569),
(1220, 1179, 27, 'create this', 1376240570),
(1221, 1179, 27, 'add a new timeline', 1376240570),
(1222, 1167, 27, 'add a new timeline', 1376241948),
(1223, 1167, 27, 'add a new timeline', 1376241951),
(1300, 1169, 5, 'assign this to KhoaNT', 1376551457),
(1299, 1155, 5, 'completed his assigned timeline(from 12-Aug-2013 to 23-Aug-2013)', 1376540418),
(1298, 1155, 5, 'uncompleted his assigned timeline(from 12-Aug-2013 to 23-Aug-2013)', 1376540385),
(1297, 1155, 5, 'completed his assigned timeline(from 12-Aug-2013 to 23-Aug-2013)', 1376540340),
(1296, 1155, 5, 'uncompleted his assigned timeline(from 12-Aug-2013 to 23-Aug-2013)', 1376540315),
(1275, 1184, 5, 'unassign KhoaNT from this', 1376290904),
(1276, 1190, 5, 'create this', 1376360790),
(1277, 1190, 5, 'assign this to KhoaNT', 1376360861);

-- --------------------------------------------------------

--
-- Table structure for table `zw_stream_priorities`
--

DROP TABLE IF EXISTS `zw_stream_priorities`;
CREATE TABLE IF NOT EXISTS `zw_stream_priorities` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `description` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `zw_tags`
--

DROP TABLE IF EXISTS `zw_tags`;
CREATE TABLE IF NOT EXISTS `zw_tags` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=73 ;

--
-- Dumping data for table `zw_tags`
--

INSERT INTO `zw_tags` (`id`, `name`) VALUES
(1, 'testing'),
(2, 'test'),
(3, 'yo'),
(4, 'ui'),
(5, 'yop'),
(6, 'ter'),
(7, 'bobo'),
(8, 'yuid'),
(9, 'saga'),
(10, 'tada'),
(11, 'loo'),
(12, 'sdfds'),
(13, 'dfdsf'),
(14, 'sdfsd'),
(15, 'sfd'),
(16, 'dsdsf'),
(17, 'dsfdsfdsf'),
(18, 'dsfdsfds'),
(19, 'fdsfs'),
(20, 'dfds'),
(21, 'jio'),
(22, 'tam'),
(23, 'yu'),
(24, 'ya'),
(25, 'ju'),
(26, 'hoa'),
(27, 'rau'),
(28, 'aft'),
(29, 'huhu'),
(30, 'koko'),
(31, 'yaya'),
(32, 'y'),
(33, 'u]'),
(34, 'hfjg'),
(35, 'h'),
(36, 'a'),
(37, 'b'),
(38, 'c'),
(39, 'u'),
(40, 'uiio'),
(41, 'yusfdsf'),
(42, 'ty'),
(43, 'fjfg'),
(44, 'amn'),
(45, 'first task'),
(46, 'guide'),
(47, 'zenwork'),
(48, 'tagging'),
(49, 'funny'),
(50, 'mine'),
(51, 'design'),
(52, 'uyen1'),
(53, 'uyen 2'),
(54, 'tag new'),
(55, 'hoho'),
(56, 'tio'),
(57, 'no'),
(58, 'ion'),
(59, 'par'),
(60, 'home'),
(61, 'database'),
(62, 'system'),
(63, 'personal'),
(64, 'daily'),
(65, 'partner'),
(66, 'uyen'),
(67, 'khoa'),
(68, 'vo chong'),
(69, 'vmas'),
(70, 'ims'),
(71, 'bug'),
(72, 'phase 2');

-- --------------------------------------------------------

--
-- Table structure for table `zw_teams`
--

DROP TABLE IF EXISTS `zw_teams`;
CREATE TABLE IF NOT EXISTS `zw_teams` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `creatorID` int(11) NOT NULL,
  `createdOn` int(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=48 ;

-- --------------------------------------------------------

--
-- Table structure for table `zw_timelines`
--

DROP TABLE IF EXISTS `zw_timelines`;
CREATE TABLE IF NOT EXISTS `zw_timelines` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `start` int(10) NOT NULL,
  `end` int(10) NOT NULL,
  `effort` float NOT NULL,
  `completed` int(1) NOT NULL DEFAULT '0',
  `sid` int(11) NOT NULL,
  `createdOn` int(10) NOT NULL,
  `creatorID` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=1179 ;

--
-- Dumping data for table `zw_timelines`
--

INSERT INTO `zw_timelines` (`id`, `start`, `end`, `effort`, `completed`, `sid`, `createdOn`, `creatorID`) VALUES
(1145, 1376586000, 1376672399, 1, 0, 1170, 1376240507, 27),
(1146, 1376672400, 1376931599, 3, 0, 1171, 1376240508, 27),
(1147, 1376931600, 1377017999, 1, 0, 1172, 1376240508, 27),
(1143, 1376154000, 1376413199, 3, 0, 1168, 1376240399, 27),
(1162, 1377709200, 1377881999, 2, 0, 1184, 1376279359, 5),
(1129, 1377450000, 1377709199, 3, 0, 1155, 1376124625, 5),
(1127, 1376240400, 1377277199, 12, 1, 1155, 1376123533, 5),
(1142, 1376154000, 1376499599, 4, 0, 1167, 1376240399, 27),
(1144, 1376413200, 1376585999, 2.5, 0, 1169, 1376240399, 27),
(1160, 1377709200, 1379091599, 16, 1, 1183, 1376278657, 5),
(1156, 1377450000, 1377795599, 4, 0, 1167, 1376241951, 27),
(1155, 1376845200, 1377017999, 2, 0, 1167, 1376241948, 27),
(1154, 1377536400, 1377622799, 1, 0, 1179, 1376240570, 27),
(1153, 1376586000, 1377017999, 5, 0, 1178, 1376240569, 27),
(1152, 1377277200, 1377536399, 3, 0, 1177, 1376240515, 27),
(1151, 1377277200, 1377622799, 4, 0, 1176, 1376240515, 27),
(1150, 1377061200, 1377277199, 2.5, 0, 1175, 1376240510, 27),
(1149, 1377061200, 1377622799, 6.5, 0, 1174, 1376240509, 27),
(1148, 1376931600, 1377017999, 1, 0, 1173, 1376240509, 27),
(1161, 1376413200, 1377277199, 10, 0, 1184, 1376279341, 5),
(1173, 1376326800, 1377277199, 5, 0, 1190, 1376413199, 5);

-- --------------------------------------------------------

--
-- Table structure for table `zw_timeline_dependancies`
--

DROP TABLE IF EXISTS `zw_timeline_dependancies`;
CREATE TABLE IF NOT EXISTS `zw_timeline_dependancies` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tID1` int(11) NOT NULL,
  `tID2` int(11) NOT NULL,
  `rel` varchar(2) COLLATE utf8_unicode_ci NOT NULL,
  `scopeID` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=73 ;

--
-- Dumping data for table `zw_timeline_dependancies`
--

INSERT INTO `zw_timeline_dependancies` (`id`, `tID1`, `tID2`, `rel`, `scopeID`) VALUES
(71, 1150, 1151, 'FF', 61),
(70, 1147, 1148, 'FF', 61),
(68, 1145, 1146, 'FS', 61),
(69, 1146, 1147, 'FS', 61);

-- --------------------------------------------------------

--
-- Table structure for table `zw_users_lists`
--

DROP TABLE IF EXISTS `zw_users_lists`;
CREATE TABLE IF NOT EXISTS `zw_users_lists` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `lid` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=23 ;

--
-- Dumping data for table `zw_users_lists`
--

INSERT INTO `zw_users_lists` (`id`, `uid`, `lid`) VALUES
(17, 27, 59),
(18, 16, 59),
(19, 6, 59),
(20, 11, 59),
(21, 12, 59),
(22, 27, 61);

-- --------------------------------------------------------

--
-- Table structure for table `zw_users_teams`
--

DROP TABLE IF EXISTS `zw_users_teams`;
CREATE TABLE IF NOT EXISTS `zw_users_teams` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tid` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=22 ;

-- --------------------------------------------------------

--
-- Table structure for table `zw_users_timelines`
--

DROP TABLE IF EXISTS `zw_users_timelines`;
CREATE TABLE IF NOT EXISTS `zw_users_timelines` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `tid` int(11) NOT NULL,
  `effort` float(11,2) NOT NULL DEFAULT '0.00',
  `completed` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=227 ;

--
-- Dumping data for table `zw_users_timelines`
--

INSERT INTO `zw_users_timelines` (`id`, `uid`, `tid`, `effort`, `completed`) VALUES
(208, 27, 1143, 2.00, 1),
(207, 27, 1142, 3.00, 1),
(223, 27, 1173, 11.00, 1),
(219, 5, 1129, 3.00, 1),
(222, 5, 1173, 11.00, 1),
(225, 6, 1161, 8.00, 1),
(209, 27, 1144, 5.00, 1),
(226, 23, 1161, 10.00, 1),
(210, 5, 1127, 4.00, 3),
(224, 5, 1144, 4.00, 3),
(217, 5, 1161, 1.00, 1),
(216, 5, 1160, 5.00, 3);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
