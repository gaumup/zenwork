-- phpMyAdmin SQL Dump
-- version 3.5.2.2
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jul 10, 2013 at 09:06 AM
-- Server version: 5.5.27
-- PHP Version: 5.4.7

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `ims_dev`
--

-- --------------------------------------------------------

--
-- Table structure for table `zw_attachments`
--

DROP TABLE IF EXISTS `zw_attachments`;
CREATE TABLE IF NOT EXISTS `zw_attachments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `filename` varchar(200) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `size` varchar(10) NOT NULL,
  `ext` varchar(5) NOT NULL,
  `uploader` int(11) NOT NULL,
  `since` int(11) NOT NULL,
  `sid` int(11) NOT NULL,
  `cid` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `zw_deliverables`
--

DROP TABLE IF EXISTS `zw_deliverables`;
CREATE TABLE IF NOT EXISTS `zw_deliverables` (
  `id` int(11) NOT NULL,
  `cateID` int(11) DEFAULT NULL,
  `statusID` int(11) DEFAULT NULL,
  `priorityID` int(11) NOT NULL DEFAULT '2',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `zw_flows`
--

DROP TABLE IF EXISTS `zw_flows`;
CREATE TABLE IF NOT EXISTS `zw_flows` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `status` int(11) NOT NULL,
  `alias` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `action` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=6 ;

--
-- Dumping data for table `zw_flows`
--

INSERT INTO `zw_flows` (`id`, `status`, `alias`, `action`) VALUES
(1, 0, 'New', 'Assign'),
(2, 1, 'Assigned', 'Accept'),
(3, 2, 'On working', 'Finish'),
(4, 3, 'Verifying', 'Close'),
(5, 4, 'Closed', '');

-- --------------------------------------------------------

--
-- Table structure for table `zw_lists`
--

DROP TABLE IF EXISTS `zw_lists`;
CREATE TABLE IF NOT EXISTS `zw_lists` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `creatorID` int(11) NOT NULL,
  `createdOn` int(10) NOT NULL,
  `description` text COLLATE utf8_unicode_ci NOT NULL,
  `ownerID` int(11) NOT NULL,
  `ownerModel` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `zw_scomments`
--

DROP TABLE IF EXISTS `zw_scomments`;
CREATE TABLE IF NOT EXISTS `zw_scomments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `comment` text COLLATE utf8_unicode_ci NOT NULL,
  `by` int(11) NOT NULL,
  `when` int(11) NOT NULL,
  `sid` varchar(13) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `zw_streams`
--

DROP TABLE IF EXISTS `zw_streams`;
CREATE TABLE IF NOT EXISTS `zw_streams` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `completed` int(1) NOT NULL,
  `creatorID` int(11) NOT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `createdOn` int(10) NOT NULL,
  `streamExtendModel` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `zw_streams_lists_map`
--

DROP TABLE IF EXISTS `zw_streams_lists_map`;
CREATE TABLE IF NOT EXISTS `zw_streams_lists_map` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sid` int(11) NOT NULL,
  `lid` int(11) NOT NULL,
  `index` int(11) DEFAULT '0',
  `parentID` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `zw_stream_followers`
--

DROP TABLE IF EXISTS `zw_stream_followers`;
CREATE TABLE IF NOT EXISTS `zw_stream_followers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `stream_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `zw_stream_logs`
--

DROP TABLE IF EXISTS `zw_stream_logs`;
CREATE TABLE IF NOT EXISTS `zw_stream_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sid` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `action` text COLLATE utf8_unicode_ci NOT NULL,
  `when` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `zw_stream_priorities`
--

DROP TABLE IF EXISTS `zw_stream_priorities`;
CREATE TABLE IF NOT EXISTS `zw_stream_priorities` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `description` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `zw_timelines`
--

DROP TABLE IF EXISTS `zw_timelines`;
CREATE TABLE IF NOT EXISTS `zw_timelines` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `start` int(10) NOT NULL,
  `end` int(10) NOT NULL,
  `completed` int(1) NOT NULL DEFAULT '0',
  `sid` int(11) NOT NULL,
  `createdOn` int(10) NOT NULL,
  `creatorID` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `zw_timeline_dependancies`
--

DROP TABLE IF EXISTS `zw_timeline_dependancies`;
CREATE TABLE IF NOT EXISTS `zw_timeline_dependancies` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tID1` int(11) NOT NULL,
  `tID2` int(11) NOT NULL,
  `rel` varchar(2) COLLATE utf8_unicode_ci NOT NULL,
  `scopeID` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `zw_users_lists`
--

DROP TABLE IF EXISTS `zw_users_lists`;
CREATE TABLE IF NOT EXISTS `zw_users_lists` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `lid` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `zw_users_timelines`
--

DROP TABLE IF EXISTS `zw_users_timelines`;
CREATE TABLE IF NOT EXISTS `zw_users_timelines` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `tid` int(11) NOT NULL,
  `effort` float(11,2) NOT NULL DEFAULT '0.00',
  `completed` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
